#ifndef KEYS_H
#define KEYS_H
bool is_enter(int c);
bool is_escape(int c);
bool is_left(int c);
bool is_down(int c);
bool is_up(int c);
bool is_right(int c);
bool is_backspace(int c);
bool is_tab(int c);
#endif
